#!/usr/bin/env python3
"""Max Day plant controller: "the tool writes the rule, the controller keeps it."

The Max Day app writes the rule (cooling water shall not exceed the cap on any day).
This program keeps it on a tabletop model plant run by a Raspberry Pi:

  left cup  = the hybrid   pours aMl in every hot hour (today's design, no cap)
  right cup = Max Day      plans its water with a fractional knapsack under the cap,
                           re-plans when the heat wave starts or stops, and a hardware
                           interlock closes its straw the moment the cap is reached.

Each straw is an arm on a servo: arm UP = no flow, arm DOWN = pours by gravity.
The physics lives in the engine's export (plant-day.json); the logic lives in plan.py.

  python3 maxday_rig.py              run the plant (Run button, joystick = heat wave)
  python3 maxday_rig.py --sim        same, with simulated pins (any laptop)
  python3 maxday_rig.py calibrate    set servo angles and measure straw flow

Keys (local terminal or SSH): r run/restart, h heat wave, x reset, u straws up, q quit.
"""
import argparse
import copy
import json
import os
import queue
import signal
import socket
import sys
import threading
import time
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

import plan

RIG_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(RIG_DIR, "config.json")
WWW_DIR = os.path.join(RIG_DIR, "www")
TICK_S = 0.02            # control loop period (50 Hz)
EASE_S = 0.25            # a full up/down swing takes about this long
CALIBRATE_POUR_S = 5.0

DEFAULT_CONFIG = {
    "pins": {"hybridServo": 18, "maxdayServo": 13, "runButton": 27, "heatButton": 17,
             "hybridTrig": 23, "hybridEcho": 24, "maxdayTrig": 5, "maxdayEcho": 6,
             "hybridLight": 22, "maxdayLight": 25},
    "straws": {"hybrid": {"upDeg": 60, "downDeg": -40, "flowMlPerS": 20.0},
               "maxday": {"upDeg": 60, "downDeg": -40, "flowMlPerS": 20.0}},
    "daySeconds": 60,
    "hybridStopMl": 520,
    "metersEnabled": False,
    "lightsEnabled": False,
    "cup": {"topDiamCm": 9.5, "bottomDiamCm": 6.0, "heightCm": 12.0},
    "meterHeightCm": {"hybrid": 16.0, "maxday": 16.0},
    "httpPort": 8000,
}


# ------------------------------------------------------------------ config ---

def merge(base, extra):
    out = copy.deepcopy(base)
    for key, value in extra.items():
        out[key] = merge(out[key], value) if isinstance(value, dict) and isinstance(out.get(key), dict) else value
    return out


def load_config():
    if not os.path.isfile(CONFIG_PATH):
        return copy.deepcopy(DEFAULT_CONFIG)
    with open(CONFIG_PATH, encoding="utf-8") as f:
        return merge(DEFAULT_CONFIG, json.load(f))


def save_config(cfg):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
        f.write("\n")
    print(f"Saved {CONFIG_PATH}")


# ---------------------------------------------------------------- hardware ---

def pigpiod_running():
    """pigpiod listens on localhost:8888 when it is up."""
    try:
        with socket.create_connection(("127.0.0.1", 8888), timeout=0.2):
            return True
    except OSError:
        return False


def is_pi5():
    try:
        with open("/proc/device-tree/model", encoding="utf-8", errors="ignore") as f:
            return "Raspberry Pi 5" in f.read()
    except OSError:
        return False


def setup_pins(sim):
    """Pick the pin factory: mock in --sim; on a Pi 3/4 pigpio if its daemon runs;
    otherwise gpiozero's default, which is lgpio on a Pi 5 with Bookworm."""
    try:
        from gpiozero import Device
    except ImportError:
        sys.exit("gpiozero is not installed. On a laptop: pip install gpiozero")
    if sim:
        from gpiozero.pins.mock import MockFactory, MockPWMPin
        Device.pin_factory = MockFactory(pin_class=MockPWMPin)
        return "mock (simulated pins)"
    if not is_pi5() and pigpiod_running():     # pigpio cannot drive a Pi 5's RP1 chip
        try:
            from gpiozero.pins.pigpio import PiGPIOFactory
        except ImportError:
            print("pigpiod is running but the pigpio Python module is missing; using the default.")
        else:
            Device.pin_factory = PiGPIOFactory()
            return "pigpio (hardware-timed servo pulses)"
    return "gpiozero default (lgpio on Pi 5 / Bookworm)"


def pin_factory_name():
    """Name of the factory gpiozero actually chose (known once a device exists)."""
    from gpiozero import Device
    return type(Device.pin_factory).__name__


class Straw:
    """One straw arm on a servo, plus its optional pour light. Moves with a short ramp."""

    def __init__(self, name, servo_pin, light_pin, settings):
        from gpiozero import LED, AngularServo
        self.name = name
        self.settings = settings            # the live dict from config (upDeg, downDeg, ...)
        self.servo = AngularServo(servo_pin, min_angle=-90, max_angle=90,
                                  min_pulse_width=0.0005, max_pulse_width=0.0025)
        self.light = LED(light_pin) if light_pin is not None else None
        self.angle = float(settings["upDeg"])
        self.target = self.angle
        self.servo.angle = self.angle

    def set_open(self, is_open):
        self.target = float(self.settings["downDeg" if is_open else "upDeg"])
        if self.light:
            self.light.value = is_open

    def aim(self, angle):
        self.target = max(-90.0, min(90.0, angle))

    def update(self, dt):
        """Step toward the target; a full up/down swing takes about EASE_S."""
        if self.angle == self.target:
            return
        swing = abs(self.settings["upDeg"] - self.settings["downDeg"]) or 1.0
        step = swing * dt / EASE_S
        delta = self.target - self.angle
        self.angle = self.target if abs(delta) <= step else self.angle + step * (1 if delta > 0 else -1)
        self.servo.angle = self.angle

    def up_and_wait(self):
        self.set_open(False)
        for _ in range(int(2 * EASE_S / TICK_S)):
            self.update(TICK_S)
            time.sleep(TICK_S)

    def close(self):
        self.servo.detach()
        self.servo.close()
        if self.light:
            self.light.close()


class Meter:
    """HC-SR04 over a cup: distance to the water -> depth -> mL. None when not sane."""

    def __init__(self, trig, echo, mount_cm, cup):
        from gpiozero import DistanceSensor
        self.sensor = DistanceSensor(echo=echo, trigger=trig, max_distance=1.0)
        self.mount_cm, self.cup = mount_cm, cup

    def read_ml(self):
        depth = self.mount_cm - self.sensor.distance * 100.0
        if not -0.5 <= depth <= self.cup["heightCm"] + 0.5:
            return None
        return plan.cup_volume_ml(depth, self.cup["topDiamCm"], self.cup["bottomDiamCm"], self.cup["heightCm"])

    def close(self):
        self.sensor.close()


def build_straws(cfg):
    pins = cfg["pins"]
    lights = cfg["lightsEnabled"]
    return {s: Straw(s, pins[f"{s}Servo"], pins[f"{s}Light"] if lights else None, cfg["straws"][s])
            for s in plan.STRAWS}


# ---------------------------------------------------------------- keyboard ---

class RawKeys:
    """Single key presses from a local terminal or SSH session (or a Windows console)."""

    def __init__(self):
        self.ok = sys.stdin.isatty()
        self.saved = None

    def __enter__(self):
        if self.ok and os.name != "nt":
            import termios
            import tty
            self.saved = termios.tcgetattr(sys.stdin.fileno())
            tty.setcbreak(sys.stdin.fileno())     # keys arrive at once; Ctrl+C still works
        return self

    def __exit__(self, *exc):
        self.restore()

    def restore(self):
        if self.saved is not None:
            import termios
            termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, self.saved)
            self.saved = None

    def read_key(self):
        if os.name == "nt":
            import msvcrt
            return msvcrt.getwch().lower()
        ch = os.read(sys.stdin.fileno(), 1)
        return ch.decode("utf-8", "ignore").lower() if ch else "q"

    def ask(self, prompt):
        """Read a whole line (temporarily leaves single-key mode)."""
        self.restore()
        try:
            return input(prompt)
        finally:
            self.__enter__()


# -------------------------------------------------------------- controller ---

class Controller:
    """Owns the plant. Only the main loop thread touches it; others send commands."""

    def __init__(self, cfg, day, data, straws, run_button, heat_button, meters):
        self.cfg, self.day, self.data = cfg, day, data
        self.straws, self.run_button, self.heat_button, self.meters = straws, run_button, heat_button, meters
        self.commands = queue.Queue()
        self.state = "idle"
        self.run = None
        self.soft_heat = False          # keyboard / HTTP heat wave
        self.quit = False
        self.run_was_pressed = False
        self.snapshot = {}
        self.meter_ml = {s: None for s in plan.STRAWS}
        self.refresh_snapshot()

    # --- commands (keyboard thread, HTTP threads) ---
    def post(self, cmd, arg=None):
        """Queue a command for the main loop; the returned Event is set once it ran."""
        done = threading.Event()
        self.commands.put((cmd, arg, done))
        return done

    def on_key(self, key):
        actions = {"r": "run", "h": "toggle_heat", "x": "reset", "u": "up", "q": "quit"}
        if key in actions:
            self.post(actions[key])

    def heat(self):
        return self.soft_heat or (self.heat_button is not None and self.heat_button.is_pressed)

    def handle(self, cmd, arg):
        if cmd == "run":
            flows = {s: self.cfg["straws"][s]["flowMlPerS"] for s in plan.STRAWS}
            self.run = plan.DayRun(self.day, flows, self.cfg["daySeconds"], heat=self.heat(),
                                   hybrid_stop_ml=self.cfg["hybridStopMl"])
            self.state = "running"
            self.log(f"RUN: day of {self.cfg['daySeconds']} s, cap {self.run.cap:.0f} mL")
        elif cmd == "reset":
            self.run, self.state = None, "idle"
            self.log("RESET: straws up, volumes 0")
        elif cmd == "up":
            self.state = "idle"
            self.log("STRAWS UP: run stopped")
        elif cmd == "toggle_heat":
            self.soft_heat = not self.soft_heat
        elif cmd == "heat":
            self.soft_heat = bool(arg)
        elif cmd == "quit":
            self.quit = True

    # --- the control loop ---
    def tick(self, dt):
        while not self.commands.empty():
            cmd, arg, done = self.commands.get_nowait()
            self.handle(cmd, arg)
            self.refresh_snapshot()
            done.set()
        pressed = self.run_button is not None and self.run_button.is_pressed
        if pressed and not self.run_was_pressed:
            self.handle("run", None)               # Run while running restarts the day
        self.run_was_pressed = pressed

        if self.state == "running":
            self.step_day(dt)
        for s, straw in self.straws.items():
            straw.set_open(self.state == "running" and self.run.valve_open(s))
            straw.update(dt)
        self.refresh_snapshot()

    def step_day(self, dt):
        run = self.run
        heat_was, lock_was, stop_was = run.heat, run.interlock, run.hybrid_stopped
        run.set_heat(self.heat())                  # re-plans when the heat wave toggles
        if run.heat != heat_was:
            self.log(f"HEAT WAVE {'ON' if run.heat else 'OFF'}: re-planned hours {run.next_hour:02d}-23"
                     f"{'  (INFEASIBLE: floors exceed what is left of the cap)' if run.infeasible else ''}")
        run.advance(dt)
        for s, meter in self.meters.items():
            self.meter_ml[s] = meter.read_ml()
            if self.meter_ml[s] is not None:
                run.use_meter(s, self.meter_ml[s])
        if run.hybrid_stopped and not stop_was:
            self.log(f"SAFETY STOP: hybrid cup reached {run.hybrid_stop:.0f} mL; straw up so the cup cannot overflow")
        if run.interlock and not lock_was:
            self.log(f"INTERLOCK: Max Day reached {run.cap:.0f} mL; straw locked up")
        if run.done:
            self.state = "done"
            self.log(f"DAY DONE: hybrid {run.poured['hybrid']:.0f} mL, Max Day {run.poured['maxday']:.0f} mL")

    def refresh_snapshot(self):
        run = self.run
        running = self.state == "running"
        self.snapshot = {
            "state": self.state,
            "hour": run.hour if run else 0,
            "t": round(run.t, 2) if run else 0.0,
            "daySeconds": self.cfg["daySeconds"],
            "heat": self.heat(),
            "hybridMl": round(run.poured["hybrid"], 1) if run else 0.0,
            "maxdayMl": round(run.poured["maxday"], 1) if run else 0.0,
            "capMl": self.day["capMl"],
            "valves": {s: bool(running and run.valve_open(s)) for s in plan.STRAWS},
            "infeasible": bool(run and run.infeasible),
            "interlock": bool(run and run.interlock),
            "hybridStop": bool(run and run.hybrid_stopped),
            "data": self.data,
            "meters": {f"{s}Ml": (round(v, 1) if v is not None else None) for s, v in self.meter_ml.items()},
        }

    # --- console ---
    def status_line(self):
        s = self.snapshot
        pour = {k: " (pouring)" if v else "" for k, v in s["valves"].items()}
        lock = " (locked)" if s["interlock"] else ""
        tail = "" if s["state"] == "running" else f"  [{s['state']}]"
        return (f"{s['hour']:02d}:00  heat:{'ON' if s['heat'] else 'off'}  "
                f"hybrid {s['hybridMl']:.0f} mL{pour['hybrid']}  "
                f"maxday {s['maxdayMl']:.0f}/{s['capMl']:.0f} mL{pour['maxday']}{lock}  "
                f"infeasible:{'YES' if s['infeasible'] else 'no'}  data:{self.data.upper()}{tail}")

    def log(self, message):
        print(f"\r\033[K{message}" if sys.stdout.isatty() else message, flush=True)

    def all_up(self):
        for straw in self.straws.values():
            straw.up_and_wait()


# -------------------------------------------------------------------- HTTP ---

def start_http(ctrl, port):
    """GET /state; POST /run, /reset, /heat {"on": bool}; rig/www/ served at / if present."""

    class Handler(SimpleHTTPRequestHandler):
        extensions_map = {**SimpleHTTPRequestHandler.extensions_map,
                          ".js": "text/javascript", ".woff2": "font/woff2", ".csv": "text/csv"}

        def __init__(self, *args, **kwargs):
            super().__init__(*args, directory=WWW_DIR, **kwargs)

        def end_headers(self):
            self.send_header("Access-Control-Allow-Origin", "*")
            super().end_headers()

        def send_json(self, code, body):
            data = json.dumps(body).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_OPTIONS(self):
            self.send_response(204)
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.send_header("Access-Control-Allow-Private-Network", "true")
            self.send_header("Access-Control-Max-Age", "600")
            self.end_headers()

        def do_GET(self):
            if self.path.split("?")[0] == "/state":
                self.send_json(200, ctrl.snapshot)
            elif os.path.isdir(WWW_DIR):
                super().do_GET()
            else:
                self.send_json(404, {"error": "no rig/www folder; try GET /state"})

        def do_POST(self):
            path = self.path.split("?")[0]
            length = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(length) if length else b""
            if path in ("/run", "/reset"):
                ctrl.post(path[1:]).wait(1.0)     # so the next GET /state shows it
                return self.send_json(200, ctrl.snapshot)
            if path == "/heat":
                try:
                    on = json.loads(raw or b"{}").get("on")
                except (ValueError, AttributeError):
                    on = None
                if not isinstance(on, bool):
                    return self.send_json(400, {"error": 'body must be {"on": true|false}'})
                ctrl.post("heat", on).wait(1.0)
                return self.send_json(200, ctrl.snapshot)
            self.send_json(404, {"error": "unknown endpoint"})

        def log_message(self, *args):
            pass   # keep the console status line readable

    server = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server


# --------------------------------------------------------------- commands ---

def load_day_or_exit():
    path, data = plan.find_day_file(RIG_DIR)
    try:
        day = plan.load_day(path)
    except (OSError, plan.DayFileError) as exc:
        sys.exit(f"Cannot use day file: {exc}")
    if data == "sample":
        bar = "!" * 64
        print(f"{bar}\n  RUNNING ON THE ILLUSTRATIVE SAMPLE DAY (plant-day.sample.json).\n"
              f"  These are NOT the engine's numbers. Copy plant-day.json into rig/.\n{bar}")
    return day, data


def raise_on_sigterm(*_):
    raise SystemExit(0)      # unwinds through the finally blocks: straws up first


def cmd_run(args):
    cfg = load_config()
    if args.day_seconds:
        cfg["daySeconds"] = args.day_seconds
    day, data = load_day_or_exit()
    factory = setup_pins(args.sim)
    from gpiozero import Button
    straws = build_straws(cfg)
    meters = {}
    try:
        pins = cfg["pins"]
        run_button = Button(pins["runButton"], pull_up=True, bounce_time=0.05)
        heat_button = Button(pins["heatButton"], pull_up=True, bounce_time=0.05)
        if cfg["metersEnabled"] and not args.sim:
            meters = {s: Meter(pins[f"{s}Trig"], pins[f"{s}Echo"], cfg["meterHeightCm"][s], cfg["cup"])
                      for s in plan.STRAWS}
        ctrl = Controller(cfg, day, data, straws, run_button, heat_button, meters)
        signal.signal(signal.SIGTERM, raise_on_sigterm)
        ctrl.all_up()
        port = args.port or cfg["httpPort"]
        server = None if args.no_http else start_http(ctrl, port)
        print(f"Max Day plant controller | pins: {factory} -> {pin_factory_name()} | day {cfg['daySeconds']} s | cap {day['capMl']} mL")
        if server:
            print(f"HTTP: http://10.42.0.1:{port}/state (hotspot) or http://localhost:{port}/state")
        print("Hotspot (run once if needed): sudo nmcli device wifi hotspot ifname wlan0 ssid MaxDay password maxday804")
        with RawKeys() as keys:
            if keys.ok:
                print("Keys: r run/restart  h heat wave  x reset  u straws up  q quit")
                threading.Thread(target=forward_keys, args=(keys, ctrl), daemon=True).start()
            else:
                print("No terminal on stdin: keyboard disabled (buttons and HTTP still work).")
            control_loop(ctrl)
    finally:
        for straw in straws.values():
            straw.up_and_wait()
            straw.close()
        for meter in meters.values():
            meter.close()
        print("\nBoth straws UP. Stopped.", flush=True)


def forward_keys(keys, ctrl):
    """Keyboard thread: hand each key to the controller's command queue."""
    while not ctrl.quit:
        ctrl.on_key(keys.read_key())


def control_loop(ctrl):
    tty = sys.stdout.isatty()
    last, last_print, last_hour = time.monotonic(), 0.0, None
    while not ctrl.quit:
        time.sleep(TICK_S)
        now = time.monotonic()
        ctrl.tick(now - last)
        last = now
        if tty and now - last_print > 0.2:
            print("\r\033[K" + ctrl.status_line(), end="", flush=True)
            last_print = now
        elif not tty and (ctrl.snapshot["hour"], ctrl.state) != last_hour:
            print(ctrl.status_line(), flush=True)      # one line per hour for logs
            last_hour = (ctrl.snapshot["hour"], ctrl.state)


def cmd_calibrate(args):
    cfg = load_config()
    setup_pins(args.sim)
    straws = build_straws(cfg)
    names = list(plan.STRAWS)
    current = 0
    try:
        with RawKeys() as keys:
            if not keys.ok:
                sys.exit("calibrate needs a keyboard: run it in a terminal or over SSH.")
            print("[ / ] move 2 deg   u save as UP   d save as DOWN   f flow test (5 s)   "
                  "n next straw   s save config   q quit")
            while True:
                name = names[current]
                straw, settings = straws[name], cfg["straws"][name]
                print(f"\r\033[K{name}: angle {straw.target:+.0f}  (up {settings['upDeg']:+.0f}, "
                      f"down {settings['downDeg']:+.0f}, flow {settings['flowMlPerS']:.1f} mL/s)", end="", flush=True)
                key = keys.read_key()
                if key in "[]":
                    straw.aim(straw.target + (2 if key == "]" else -2))
                elif key == "u":
                    settings["upDeg"] = straw.target
                elif key == "d":
                    settings["downDeg"] = straw.target
                elif key == "n":
                    straw.up_and_wait()
                    current = (current + 1) % len(names)
                    straws[names[current]].aim(cfg["straws"][names[current]]["upDeg"])
                elif key == "f":
                    measure_flow(straw, settings, keys)
                elif key == "s":
                    print()
                    save_config(cfg)
                elif key == "q":
                    break
                for _ in range(int(EASE_S / TICK_S) + 2):
                    straw.update(TICK_S)
                    time.sleep(TICK_S)
    finally:
        for straw in straws.values():
            straw.up_and_wait()
            straw.close()
        print("\nBoth straws UP. Unsaved changes (if any) were not written.")


def measure_flow(straw, settings, keys):
    print(f"\nPouring for {CALIBRATE_POUR_S:.0f} s into an empty marked cup...")
    straw.set_open(True)
    end = time.monotonic() + CALIBRATE_POUR_S
    while time.monotonic() < end:
        straw.update(TICK_S)
        time.sleep(TICK_S)
    straw.up_and_wait()
    answer = keys.ask("mL in the cup (Enter to skip): ").strip()
    if answer:
        try:
            ml = float(answer)
        except ValueError:
            print("Not a number; flow unchanged.")
            return
        settings["flowMlPerS"] = round(ml / CALIBRATE_POUR_S, 2)
        print(f"flowMlPerS = {settings['flowMlPerS']} (press s to save)")


def main():
    p = argparse.ArgumentParser(description="Max Day plant controller")
    p.add_argument("command", nargs="?", default="run", choices=["run", "calibrate"])
    p.add_argument("--sim", action="store_true", help="simulated pins (gpiozero MockFactory)")
    p.add_argument("--day-seconds", type=float, help="override daySeconds from config.json")
    p.add_argument("--port", type=int, help="HTTP port (default from config.json, 8000)")
    p.add_argument("--no-http", action="store_true", help="do not start the HTTP interface")
    args = p.parse_args()
    (cmd_calibrate if args.command == "calibrate" else cmd_run)(args)


if __name__ == "__main__":
    main()
