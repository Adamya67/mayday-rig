"""Tests for plan.py. Run from rig/:  pytest -q"""
import copy
import itertools
import json
import os
from pathlib import Path

import pytest

import plan

RIG_DIR = os.path.dirname(os.path.abspath(__file__))
FLOW = {"hybrid": 20.0, "maxday": 20.0}


@pytest.fixture(scope="module")
def sample():
    return plan.load_day(os.path.join(RIG_DIR, "plant-day.sample.json"))


def hours_of(rows):
    """[(aMl, bKWh, wMin), ...] -> hour dicts."""
    return [{"h": i, "tempC": 30.0, "hybridWet": True, "aMl": a, "bKWh": b, "wMin": m}
            for i, (a, b, m) in enumerate(rows)]


def cost(w, hours):
    return sum(wi * h["aMl"] for wi, h in zip(w, hours))


def saved(w, hours):
    return sum(wi * h["bKWh"] for wi, h in zip(w, hours))


def brute_force_best(hours, budget):
    """Exact optimum by enumerating LP vertices: every w at a bound, except at most one."""
    n, best = len(hours), None
    for bounds in itertools.product((0, 1), repeat=n):
        base = [hours[i]["wMin"] if b == 0 else 1.0 for i, b in enumerate(bounds)]
        candidates = [base]
        for j in range(n):          # let hour j take whatever budget is left
            if hours[j]["aMl"] > 0:
                w = list(base)
                w[j] = (budget - cost(base, hours) + base[j] * hours[j]["aMl"]) / hours[j]["aMl"]
                candidates.append(w)
        for w in candidates:
            ok = all(h["wMin"] - 1e-9 <= wi <= 1 + 1e-9 for wi, h in zip(w, hours))
            if ok and cost(w, hours) <= budget + 1e-9:
                best = saved(w, hours) if best is None else max(best, saved(w, hours))
    return best


def play(day, heat_at=(), dt=0.02, day_seconds=24.0):
    """Run a whole day; heat_at is a list of (time_s, on) toggles."""
    run = plan.DayRun(day, FLOW, day_seconds)
    toggles = sorted(heat_at)
    peak_committed = 0.0
    while not run.done:
        while toggles and run.t >= toggles[0][0]:
            run.set_heat(toggles.pop(0)[1])
        run.advance(dt)
        future = sum(run.maxday_plan_ml[run.next_hour:])
        peak_committed = max(peak_committed, run.committed_ml() + future)
    return run, peak_committed


# --------------------------------------------------------------- knapsack ---

def test_cap_respected():
    hours = hours_of([(10, 50, 0), (20, 60, 0), (5, 40, 0), (30, 90, 0)])
    w, infeasible = plan.plan_hours(hours, 25)
    assert not infeasible
    assert cost(w, hours) == pytest.approx(25)
    assert all(0 <= wi <= 1 for wi in w)


def test_floors_respected():
    hours = hours_of([(10, 1, 0.5), (20, 100, 0), (10, 1, 0.3)])
    w, infeasible = plan.plan_hours(hours, 15)
    assert not infeasible
    assert w[0] >= 0.5 and w[2] >= 0.3          # floors kept even though they pay little
    assert cost(w, hours) == pytest.approx(15)


def test_infeasible_flagged_and_floors_kept():
    hours = hours_of([(40, 10, 1.0), (40, 10, 0.5)])
    w, infeasible = plan.plan_hours(hours, 30)
    assert infeasible
    assert w == [1.0, 0.5]                        # never silently drop the peak floor


def test_greedy_takes_best_kwh_per_ml_first():
    hours = hours_of([(10, 10, 0), (10, 100, 0), (10, 50, 0)])
    w, _ = plan.plan_hours(hours, 15)
    assert w == pytest.approx([0, 1, 0.5])


@pytest.mark.parametrize("seed", range(40))
def test_equals_brute_force(seed):
    import random
    rng = random.Random(seed)
    n = rng.randint(1, 5)
    hours = hours_of([(rng.choice([0, 3, 7, 12.5, 20]), rng.uniform(0, 100),
                       rng.choice([0, 0, 0.2, 0.5, 1.0])) for _ in range(n)])
    budget = rng.uniform(0, 50)
    w, infeasible = plan.plan_hours(hours, budget)
    floors = sum(h["wMin"] * h["aMl"] for h in hours)
    assert infeasible == (floors > budget + 1e-9)
    if not infeasible:
        assert cost(w, hours) <= budget + 1e-9
        assert saved(w, hours) == pytest.approx(brute_force_best(hours, budget), abs=1e-6)


# -------------------------------------------------------------- whole day ---

def test_hybrid_total_equals_sum_of_wet_hours(sample):
    run, _ = play(sample)
    expected = sum(h["aMl"] for h in sample["normal"]["hours"] if h["hybridWet"])
    assert run.poured["hybrid"] == pytest.approx(expected, abs=1e-6)
    assert expected == pytest.approx(415, abs=1)


def test_maxday_stops_at_cap(sample):
    run, peak = play(sample)
    assert run.poured["maxday"] == pytest.approx(sample["capMl"], abs=1e-6)
    assert peak <= sample["capMl"] + 1e-6
    assert not run.infeasible


@pytest.mark.parametrize("toggles", [
    [(13.0, True)],                               # heat wave from 1 PM
    [(14.4, True), (17.1, False)],                # mid-afternoon burst
    [(0.0, True)],                                # whole day hot
    [(3.3, True), (8.8, False), (12.2, True), (19.9, False)],
])
def test_replan_after_heat_toggle_never_exceeds_cap(sample, toggles):
    run, peak = play(sample, heat_at=toggles)
    assert run.poured["maxday"] <= sample["capMl"] + 1e-6
    assert peak <= sample["capMl"] + 1e-6        # plan + queue + poured, at every step
    assert run.done


def test_heat_wave_raises_hybrid_but_not_maxday(sample):
    calm, _ = play(sample)
    hot, _ = play(sample, heat_at=[(14.0, True)])
    assert hot.poured["hybrid"] > calm.poured["hybrid"] + 20
    assert hot.poured["maxday"] == pytest.approx(sample["capMl"], abs=1e-6)


def test_interlock_closes_maxday_whatever_the_plan(sample):
    day = copy.deepcopy(sample)
    day["capMl"] = 100
    run = plan.DayRun(day, FLOW, 24)
    run.maxday_plan_ml = [50.0] * 24              # a plan that ignores the cap
    while not run.done:
        run.advance(0.05)
    assert run.interlock
    assert run.poured["maxday"] == pytest.approx(100)
    assert not run.valve_open("maxday")


def test_meter_reading_can_trip_interlock(sample):
    run = plan.DayRun(sample, FLOW, 24)
    run.use_meter("maxday", 250)
    assert run.interlock and not run.valve_open("maxday")


# ------------------------------------------------------------- pour queue ---

def test_pour_spills_into_next_hours_then_drains():
    day = {"capMl": 1000, "galPerMl": 2150,
           "normal": {"hours": hours_of([(0, 0, 0)] * 23 + [(100, 1, 0)])},
           "heatWave": {"hours": hours_of([(0, 0, 0)] * 24)}}
    run = plan.DayRun(day, FLOW, 24)               # 1 s hours; 100 mL = 5 s of pouring
    run.advance(24.5)
    assert run.valve_open("hybrid") and not run.done
    while not run.done:
        run.advance(0.01)
    assert run.poured["hybrid"] == pytest.approx(100)
    assert run.t == pytest.approx(28, abs=0.02)


def test_straw_opens_at_start_of_hour_for_ml_over_flow():
    day = {"capMl": 1000, "galPerMl": 2150,
           "normal": {"hours": hours_of([(0, 0, 0), (10, 1, 0)] + [(0, 0, 0)] * 22)},
           "heatWave": {"hours": hours_of([(0, 0, 0)] * 24)}}
    run = plan.DayRun(day, FLOW, 24)
    run.advance(0.9)
    assert not run.valve_open("hybrid")
    run.advance(0.2)                                # t = 1.1 s, inside hour 1
    assert run.valve_open("hybrid")
    run.advance(0.5)                                # 10 mL / 20 mL/s = 0.5 s
    assert not run.valve_open("hybrid")
    assert run.poured["hybrid"] == pytest.approx(10)


# --------------------------------------------------------------- day file ---

def test_sample_file_is_valid_and_marked(sample):
    assert sample["illustrative"] is True
    temps = [h["tempC"] for h in sample["normal"]["hours"]]
    assert temps.index(max(temps)) == 15 and 34 <= max(temps) <= 36


@pytest.mark.parametrize("breakage, message", [
    (lambda d: d["normal"]["hours"].pop(), "exactly 24"),
    (lambda d: d["heatWave"]["hours"][5].update(aMl=-1), "negative"),
    (lambda d: d["normal"]["hours"][3].update(wMin=1.5), "between 0 and 1"),
    (lambda d: d["normal"]["hours"][3].update(bKWh="lots"), "number"),
    (lambda d: d["normal"]["hours"][7].update(h=8), "'h' must be 7"),
    (lambda d: d.pop("capMl"), "capMl"),
])
def test_invalid_day_rejected(sample, tmp_path, breakage, message):
    day = copy.deepcopy(sample)
    breakage(day)
    path = tmp_path / "bad.json"
    path.write_text(json.dumps(day))
    with pytest.raises(plan.DayFileError, match=message):
        plan.load_day(str(path))


def test_cup_volume_matches_brief_geometry():
    vol = lambda d: plan.cup_volume_ml(d, 9.5, 6.0, 12.0)
    assert vol(12.0) == pytest.approx(576, abs=1)
    assert vol(6.4) == pytest.approx(242, abs=2)
    assert vol(9.5) == pytest.approx(415, abs=5)


def _real_day():
    return plan.load_day(str(Path(__file__).parent / "plant-day.json"))


def test_real_day_file_validates_and_matches_engine_totals():
    day = _real_day()
    hy = sum(plan.hybrid_ml(h) for h in day["normal"]["hours"])
    assert abs(hy - 415) < 1
    assert day["capMl"] == 242


def test_real_day_normal_run_ends_near_415_and_242():
    run = plan.DayRun(_real_day(), FLOW, 24)
    while not run.done:
        run.advance(0.05)
    assert abs(run.poured["hybrid"] - 415) < 1
    assert abs(run.poured["maxday"] - 242) < 0.5
    assert not run.hybrid_stopped


def test_hybrid_safety_stop_at_520_with_heat_wave_all_day():
    run = plan.DayRun(_real_day(), FLOW, 24, heat=True)
    while not run.done:
        run.advance(0.05)
    assert run.hybrid_stopped
    assert run.poured["hybrid"] <= 520 + 1e-6
    assert run.poured["maxday"] <= 242 + 1e-6
