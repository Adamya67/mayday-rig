"""Pure logic for the Max Day plant controller: no clock, no GPIO, no printing.

  load_day()       read and validate plant-day.json (the engine's export)
  plan_hours()     the fractional knapsack: floors first, then best kWh-per-mL hours
  DayRun           one simulated day for both plants: pour queues, heat-wave
                   re-plans, and the cap interlock. Stepped with fake time in tests,
                   with the real clock by maxday_rig.py.
  cup_volume_ml()  water volume in a tapered cup from its depth (for the meters)
"""
import json
import math
import os

HOURS = 24
STRAWS = ("hybrid", "maxday")
HYBRID_STOP_ML = 520.0     # close the hybrid straw here whatever the plan says (cup overflow guard)
EPS = 1e-9
HOUR_FIELDS = ("tempC", "aMl", "bKWh", "wMin")


class DayFileError(ValueError):
    """The day file is missing a field or has a value the controller cannot trust."""


# ------------------------------------------------------------------ day file ---

def find_day_file(rig_dir):
    """Prefer the engine's real export; fall back to the illustrative sample."""
    real = os.path.join(rig_dir, "plant-day.json")
    if os.path.isfile(real):
        return real, "real"
    return os.path.join(rig_dir, "plant-day.sample.json"), "sample"


def load_day(path):
    with open(path, encoding="utf-8") as f:
        try:
            day = json.load(f)
        except json.JSONDecodeError as exc:
            raise DayFileError(f"{path}: not valid JSON ({exc})") from exc
    validate_day(day)
    return day


def validate_day(day):
    """Raise DayFileError unless the day matches the contract in the brief (section 5)."""
    for key in ("capMl", "galPerMl"):
        if not _is_number(day.get(key)) or day[key] <= 0:
            raise DayFileError(f"'{key}' must be a positive number")
    for table in ("normal", "heatWave"):
        hours = (day.get(table) or {}).get("hours")
        if not isinstance(hours, list) or len(hours) != HOURS:
            raise DayFileError(f"'{table}.hours' must have exactly {HOURS} entries")
        for i, hour in enumerate(hours):
            where = f"{table}.hours[{i}]"
            if hour.get("h") != i:
                raise DayFileError(f"{where}: 'h' must be {i}")
            if not isinstance(hour.get("hybridWet"), bool):
                raise DayFileError(f"{where}: 'hybridWet' must be true or false")
            for field in HOUR_FIELDS:
                if not _is_number(hour.get(field)):
                    raise DayFileError(f"{where}: '{field}' must be a number")
            for field in ("aMl", "bKWh", "wMin"):
                if hour[field] < 0:
                    raise DayFileError(f"{where}: '{field}' must not be negative")
            if hour["wMin"] > 1:
                raise DayFileError(f"{where}: 'wMin' must be between 0 and 1")


def _is_number(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def hybrid_ml(hour):
    """The hybrid's rule: fully wet in a hot hour, dry otherwise."""
    return hour["aMl"] if hour["hybridWet"] else 0.0


# ------------------------------------------------------------- the knapsack ---

def plan_hours(hours, budget_ml):
    """Choose a wet fraction w for each hour to save the most kWh within budget_ml.

    1. Every hour gets its peak-power floor w = wMin. If the floors alone cost more
       than the budget the cap is infeasible: keep the floors (never break the peak
       limit silently) and report infeasible=True.
    2. Spend what is left on the hours with the most kWh saved per mL, raising each
       to w = 1, the last one fractionally. For a fractional knapsack this greedy
       order is provably optimal.
    Returns (list of w, infeasible).
    """
    w = [h["wMin"] for h in hours]
    left = budget_ml - sum(wi * h["aMl"] for wi, h in zip(w, hours))
    if left < -EPS:
        return w, True
    for i, h in enumerate(hours):
        if h["aMl"] <= 0:
            w[i] = 1.0                 # wetting this hour costs no water
    ranked = sorted((i for i, h in enumerate(hours) if h["aMl"] > 0 and h["bKWh"] > 0),
                    key=lambda i: hours[i]["bKWh"] / hours[i]["aMl"], reverse=True)
    for i in ranked:
        if left <= EPS:
            break
        room_ml = (1.0 - w[i]) * hours[i]["aMl"]
        take_ml = min(room_ml, left)
        w[i] += take_ml / hours[i]["aMl"]
        left -= take_ml
    return w, False


# ------------------------------------------------------- one simulated day ---

class DayRun:
    """Both plants over one day of day_seconds. Call advance(dt); read the fields.

    Pouring: at the start of hour h each straw's queue gets ml / flow seconds of
    pouring. The straw stays open while it owes time, so a big hour spills into the
    next. After hour 23 the queues drain, then the day is done.

    Max Day plans the hours that have not started yet with budget
    cap - (poured + already queued). It re-plans whenever the heat wave toggles.
    The interlock is separate from the plan: Max Day's straw closes the moment its
    poured volume reaches the cap, whatever the plan says.
    """

    def __init__(self, day, flow_ml_per_s, day_seconds, heat=False, hybrid_stop_ml=HYBRID_STOP_ML):
        self.day = day
        self.cap = float(day["capMl"])
        # Safety stop, not part of the model: a 16 oz cup holds about 576 mL brimful,
        # and a whole day of heat wave would pour about 592 mL into the hybrid's cup.
        self.hybrid_stop = float(hybrid_stop_ml)
        self.hybrid_stopped = False
        self.flow = {s: float(flow_ml_per_s[s]) for s in STRAWS}
        self.day_seconds = float(day_seconds)
        self.hour_s = self.day_seconds / HOURS
        self.heat = heat
        self.t = 0.0
        self.next_hour = 0                          # first hour not yet started
        self.owed_s = {s: 0.0 for s in STRAWS}      # pour queue, in seconds
        self.poured = {s: 0.0 for s in STRAWS}      # mL, from valve-open time x flow
        self.maxday_plan_ml = [0.0] * HOURS
        self.infeasible = False
        self.interlock = False
        self.done = False
        self.replan()
        self._start_due_hours()

    @property
    def hour(self):
        return min(HOURS - 1, int(self.t / self.hour_s + EPS))

    def table(self):
        return self.day["heatWave" if self.heat else "normal"]["hours"]

    def committed_ml(self):
        """Max Day water already poured or queued: the part a re-plan cannot change."""
        return self.poured["maxday"] + self.owed_s["maxday"] * self.flow["maxday"]

    def replan(self):
        """Plan the hours not started yet with whatever is left of the cap."""
        first = self.next_hour
        budget = max(0.0, self.cap - self.committed_ml())
        hours = self.table()[first:]
        w, self.infeasible = plan_hours(hours, budget)
        for offset, (wi, h) in enumerate(zip(w, hours)):
            self.maxday_plan_ml[first + offset] = wi * h["aMl"]

    def set_heat(self, on):
        if on == self.heat:
            return
        self.heat = on
        if not self.done:
            self.replan()

    def valve_open(self, straw):
        if self.done or (straw == "maxday" and self.interlock):
            return False
        if straw == "hybrid" and self.hybrid_stopped:
            return False
        return self.owed_s[straw] > EPS

    def _start_due_hours(self):
        while self.next_hour < HOURS and self.next_hour * self.hour_s <= self.t + EPS:
            h = self.next_hour
            self.owed_s["hybrid"] += hybrid_ml(self.table()[h]) / self.flow["hybrid"]
            self.owed_s["maxday"] += self.maxday_plan_ml[h] / self.flow["maxday"]
            self.next_hour += 1

    def advance(self, dt):
        end = self.t + dt
        while not self.done and self.t < end - 1e-12:
            self._start_due_hours()
            boundary = self.next_hour * self.hour_s if self.next_hour < HOURS else end
            step_end = min(end, boundary)
            for s in STRAWS:
                if self.valve_open(s):
                    self._pour(s, min(self.owed_s[s], step_end - self.t))
            self.t = step_end
            idle = not any(self.valve_open(s) for s in STRAWS)
            if self.next_hour >= HOURS and self.t >= self.day_seconds - EPS and idle:
                self.done = True

    def _pour(self, straw, open_s):
        ml = open_s * self.flow[straw]
        if straw == "maxday" and self.poured[straw] + ml >= self.cap - EPS:
            ml = max(0.0, self.cap - self.poured[straw])      # INTERLOCK
            self.interlock = True
        if straw == "hybrid" and self.poured[straw] + ml >= self.hybrid_stop - EPS:
            ml = max(0.0, self.hybrid_stop - self.poured[straw])  # overflow safety stop
            self.hybrid_stopped = True
        self.owed_s[straw] = max(0.0, self.owed_s[straw] - open_s)
        self.poured[straw] += ml

    def use_meter(self, straw, ml):
        """A sane meter reading replaces the valve-time estimate (and can trip the lock)."""
        self.poured[straw] = ml
        if straw == "maxday" and ml >= self.cap - EPS:
            self.interlock = True
        if straw == "hybrid" and ml >= self.hybrid_stop - EPS:
            self.hybrid_stopped = True


# ---------------------------------------------------------------- meters ---

def cup_volume_ml(depth_cm, top_diam_cm, bottom_diam_cm, height_cm):
    """Volume of water depth_cm deep in a cup shaped like a truncated cone."""
    d = min(max(depth_cm, 0.0), height_cm)
    r0 = bottom_diam_cm / 2
    r1 = r0 + (top_diam_cm - bottom_diam_cm) / 2 * d / height_cm
    return math.pi * d / 3 * (r0 * r0 + r0 * r1 + r1 * r1)   # cm^3 = mL
