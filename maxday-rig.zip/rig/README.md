# Max Day plant controller (Raspberry Pi 5)

The Max Day app writes the rule; this controller keeps it on the model plant. Left cup is
the hybrid (pours in every hot hour, no cap). Right cup is Max Day: a fractional knapsack plans
its water under the cap, it re-plans when the heat wave starts or stops, and an interlock
closes its straw the moment it reaches the cap. Arm UP = no flow, arm DOWN = pours.

| File | What it is |
|---|---|
| `maxday_rig.py` | the controller: `run` (default), `calibrate`, `--sim` |
| `plan.py` | pure logic: day-file validation, knapsack, re-plan, pour queue, interlock |
| `test_plan.py` | tests (`pytest -q`) |
| `plant-day.json` | the engine's export for 24 June 2025 (used when present) |
| `plant-day.sample.json` | illustrative stand-in; the controller warns loudly when using it |
| `config.json` | pins, servo angles, flow, day length, options |

## Wiring (BCM numbers, physical pin in brackets)

| Part | Pin |
|---|---|
| Hybrid servo signal | GPIO18 (12) |
| Max Day servo signal | GPIO13 (33) |
| Servo 5 V and GND | USB power bank lead; bank GND tied to Pi GND (6). Never the Pi's 5 V pin. |
| Run button | GPIO27 (13) to GND (internal pull-up) |
| Joystick press SW (heat wave) | GPIO17 (11) to GND (internal pull-up); joystick +5V/GND to 5 V (2) / GND |
| Meter 1 / 2 trig, echo (optional) | GPIO23/24 (16/18), GPIO5/6 (29/31); echo via 1 kOhm + 2 kOhm divider |
| Pour lights (optional) | GPIO22 (15) / GPIO25 (22), 220 Ohm each |

Meters and lights are off by default (`metersEnabled`, `lightsEnabled` in `config.json`).

## Pi 5 setup (over SSH)

1. Copy the folder: `scp -r rig maxday@<pi-address>:~/maxday/` (plus `plant-day.json` when the engine exports it).
2. Libraries (preinstalled on Raspberry Pi OS Bookworm; this only fills gaps):
   `sudo apt install -y python3-gpiozero python3-lgpio tmux`
3. Pin factory: on a Pi 5 the controller uses gpiozero's default, **lgpio**. (pigpio does not
   support the Pi 5. On a Pi 3/4 it is used automatically when `pigpiod` is running.) The
   startup line prints the factory in use.
4. Run inside tmux so an SSH drop does not stop the plant: `tmux new -s maxday`, then
   `cd ~/maxday/rig && python3 maxday_rig.py`. Detach with Ctrl+B then D; return with `tmux attach -t maxday`.

## Calibrate (do this on site, jug filled to its demo level)

`python3 maxday_rig.py calibrate`
- `[` / `]` moves the selected arm 2 degrees, `n` switches straw.
- `u` saves the current angle as UP: the tip is above the jug's water line. `d` saves DOWN: the tip hangs over its cup.
- `f` pours for 5 s into an empty marked cup, then asks how many mL you read: sets `flowMlPerS`.
- `s` writes `config.json`. `q` quits. Both straws go up on exit.

## Run

`python3 maxday_rig.py` (or `--sim` on any laptop with `pip install gpiozero`).
- **Run button** (or key `r`): reset volumes and play the day (60 s, 2.5 s per hour). Run again restarts.
- **Hold the joystick** (or key `h` to toggle): heat wave. Both plants switch to the heat-wave table and Max Day re-plans what is left of its cap.
- Keys: `r` run, `h` heat wave, `x` reset, `u` both straws up (stops the run), `q` quit.
- Console line: `14:00  heat:ON  hybrid 312 mL (pouring)  maxday 198/242 mL  infeasible:no  data:REAL`
- HTTP on port 8000: `GET /state`; `POST /run`, `POST /reset`, `POST /heat` with `{"on": true}`. CORS and
  Private-Network preflights are answered so the app can call it. If `rig/www/` exists it is served at `/`.

Wi-Fi without the venue network: `sudo nmcli device wifi hotspot ifname wlan0 ssid MaxDay password maxday804`.
The Pi becomes `10.42.0.1`. **If you are on SSH over Wi-Fi this drops your session:** join the laptop
to "MaxDay" (password `maxday804`) and `ssh maxday@10.42.0.1`. Start the controller in tmux first.

Autostart (optional): see `maxday-rig.service` (no keyboard there; buttons and HTTP work).

## Troubleshooting

| Symptom | Fix |
|---|---|
| `GPIO busy` / `lgpio.error` at start | another copy is running: `sudo systemctl stop maxday-rig` or close the other tmux window |
| servo twitches or buzzes at rest | Pi 5 servo pulses are software-timed, so some jitter is normal; check power bank GND is tied to Pi GND; slightly shrink the up/down angles so the servo does not push against the stick |
| servo does not move | signal wire on the right pin? servo powered from the bank, not the Pi? |
| a straw dribbles when UP | raise `upDeg` until the tip is clearly above the water line |
| cups end over or under | re-run the `f` flow test with the jug at its demo level; flow drops as the jug empties |
| `data:SAMPLE` on the console | copy the engine's `plant-day.json` into `rig/` |
| `infeasible:YES` | the peak-power floors need more water than is left of the cap; the controller keeps the floors and the interlock still stops at the cap |
| keys do nothing | the program needs a terminal (SSH or tmux); under systemd use the buttons |

## 2-minute pre-demo checklist

1. Jug filled to the demo mark; both plant cups empty and dry; red cap lines visible.
2. `tmux attach -t maxday`: console shows `data:REAL` and `[idle]`; both arms up, no dribble.
3. Press `x` (reset), then the Run button: the hybrid straw drops in the first hot hour.
4. Hold the joystick around 14:00 for the heat wave; Max Day's straw swings up at the red line.
5. After the run: empty the cups, refill the jug, press `x`.

## Real day file and the hybrid safety stop
- `rig/plant-day.json` comes from the engine (`npm test` writes it). Don't hand-edit it; the console shows `data:REAL` when it loads.
- **Safety stop:** the hybrid straw closes at **520 mL** (`hybridStopMl` in config.json), whatever the plan says, and logs `SAFETY STOP`. A 16 oz cup holds about 576 mL brimful.
- Tested in `--sim` with a 60 s day: normal day hybrid 415 mL, Max Day 242 mL. Heat wave held 13:00 to 17:00: hybrid 416 mL (those hours are already wet, so it barely changes). Heat wave held all day: hybrid stops at 520 mL, Max Day still 242 mL.
